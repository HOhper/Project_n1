from django.shortcuts import render

def rewar(request):
    return render(request,'App/index1.html')
# Create your views here.
